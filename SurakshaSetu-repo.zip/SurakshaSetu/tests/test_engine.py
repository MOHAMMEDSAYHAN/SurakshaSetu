import json, pathlib
from surakshasetu import VerdictEngine, Risk
from surakshasetu.l1_lookup import KnownThreats

ROOT = pathlib.Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "sample"


def engine():
    return VerdictEngine(KnownThreats().load_csv(str(DATA / "known_threats.csv")))


def test_known_number_is_red():
    assert engine().check("Call me on 90000 00001 for your reward").risk == Risk.RED


def test_known_upi_is_red():
    assert engine().check("Pay to lottery.winner@fakebank").risk == Risk.RED


def test_fake_kyc_sms_is_red():
    v = engine().check("Dear customer your SBI account will be blocked today. Update KYC http://sbi-kyc-update.xyz")
    assert v.risk == Risk.RED


def test_digital_arrest_english_is_red():
    v = engine().check("This is CBI. Digital arrest warrant issued. Stay on video call, do not tell anyone.")
    assert v.risk == Risk.RED and v.scam_type == "digital_arrest"


def test_legit_bank_link_not_flagged():
    assert engine().check("Login at https://onlinesbi.sbi").risk == Risk.GREEN


def test_otp_notice_not_flagged():
    assert engine().check("Your OTP for login is 123456. Do not share it with anyone.").risk == Risk.GREEN


def test_all_sample_scam_scripts_at_least_amber():
    e = engine()
    rows = [json.loads(l) for l in (DATA / "scam_scripts.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    misses = [r for r in rows if e.check(r["text"]).risk == Risk.GREEN]
    assert not misses, f"missed: {misses}"


def test_benign_samples_are_green():
    e = engine()
    rows = [json.loads(l) for l in (DATA / "benign.jsonl").read_text(encoding="utf-8").splitlines() if l.strip()]
    fps = [r for r in rows if e.check(r["text"]).risk != Risk.GREEN]
    assert not fps, f"false positives: {fps}"
