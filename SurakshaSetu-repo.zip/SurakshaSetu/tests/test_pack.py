import json, pathlib, pack_tool
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from surakshasetu import VerdictEngine, Risk
from surakshasetu.l1_lookup import KnownThreats

CSV = pathlib.Path(__file__).resolve().parents[1] / "data" / "sample" / "known_threats.csv"


def keys():
    k = Ed25519PrivateKey.generate()
    priv = k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
    pub = k.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    return priv, pub


def test_sign_verify_roundtrip():
    priv, pub = keys()
    signed = pack_tool.sign(pack_tool.build(str(CSV), 3), priv)
    assert pack_tool.verify(signed, pub)


def test_tampered_pack_rejected():
    priv, pub = keys()
    signed = pack_tool.sign(pack_tool.build(str(CSV), 3), priv)
    signed["entries"].append({"type": "phone", "sha256": "00" * 32})
    assert not pack_tool.verify(signed, pub)


def test_wrong_key_rejected():
    priv, _ = keys()
    _, other_pub = keys()
    signed = pack_tool.sign(pack_tool.build(str(CSV), 1), priv)
    assert not pack_tool.verify(signed, other_pub)


def test_engine_uses_pack_entries():
    pack = pack_tool.build(str(CSV), 1)
    e = VerdictEngine(KnownThreats().load_entries(pack["entries"]))
    assert e.check("call 9000000001").risk == Risk.RED
