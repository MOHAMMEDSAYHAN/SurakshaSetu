# Android app (skeleton)

- Kotlin, Jetpack, minSdk 24 (Android 7+), target APK < 60 MB
- Modules planned: `engine` (pure Kotlin, mirrors `reference/`), `asr` (whisper.cpp JNI / Vosk), `voice` (clips + offline TTS),
  `storage` (SQLCipher), `sync` (signed packs: Wi-Fi / Bluetooth / QR), `guardian` (opt-in SMS)
- Open in Android Studio and create the Gradle project around `app/src/main/java/org/surakshasetu/engine`.
- Keep `engine` free of Android dependencies so it can be unit-tested on the JVM against `data/sample/*.jsonl`.
