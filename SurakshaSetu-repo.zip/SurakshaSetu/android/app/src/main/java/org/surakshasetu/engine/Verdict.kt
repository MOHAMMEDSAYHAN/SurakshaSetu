package org.surakshasetu.engine

enum class Risk { GREEN, AMBER, RED }   // GREEN = no known threat, never "100% safe"

data class Verdict(
    val risk: Risk,
    val scamType: String? = null,
    val reasons: List<String> = emptyList(),
)
