package org.surakshasetu.engine

interface ThreatStore { fun contains(kind: String, normalised: String): Boolean }
interface IntentModel { fun score(text: String): Triple<String?, Float, List<String>> }   // TFLite-backed
interface LinkRules  { fun score(text: String, hosts: List<String>): Pair<Float, List<String>> }

/** Mirrors reference/surakshasetu/engine.py. Thresholds must match until tuned on field data. */
class VerdictEngine(
    private val store: ThreatStore,
    private val intent: IntentModel,
    private val rules: LinkRules,
) {
    fun check(text: String, phones: List<String>, upis: List<String>, hosts: List<String>): Verdict {
        val l1 = buildList {
            phones.filter { store.contains("phone", it) }.forEach { add("number is in known-scam list") }
            upis.filter { store.contains("upi", it) }.forEach { add("UPI ID is in known-scam list") }
            hosts.filter { store.contains("host", it) }.forEach { add("link is in known-scam list") }
        }
        val (type, l2, _) = intent.score(text)
        val (l3, l3Reasons) = rules.score(text, hosts)
        if (l1.isNotEmpty()) return Verdict(Risk.RED, type, l1 + l3Reasons)

        val combined = minOf(1f, maxOf(l2, l3) + 0.3f * minOf(l2, l3))
        val risk = when {
            combined >= 0.75f -> Risk.RED
            combined >= 0.35f -> Risk.AMBER
            else -> Risk.GREEN
        }
        return Verdict(risk, if (risk == Risk.GREEN) null else type, l3Reasons)
    }
}
