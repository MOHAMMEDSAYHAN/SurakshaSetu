# Privacy & Data Handling

- **On-device only**: ASR, intent model and rules run locally. No cloud AI at runtime.
- **No audio stored**: audio buffers are discarded right after transcription.
- **Consent first**: microphone, SMS and Family Guardian features each need explicit, spoken+tap consent.
- **Encrypted store**: threat data in SQLCipher (AES-256).
- **Opt-in reporting**: anonymised scam-script / identifier reports only; no personal identifiers; can be turned off anytime.
- **Family Guardian**: SMS goes only to the contact the user chose, only on RED, only when opted in.
- Designed to align with the Digital Personal Data Protection Act, 2023 (legal review pending).
