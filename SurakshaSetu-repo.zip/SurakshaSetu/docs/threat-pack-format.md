# Threat Pack Format (v1)

```json
{
  "format": 1,
  "version": 12,
  "created": "2026-10-27T10:00:00Z",
  "entries": [
    {"type": "phone", "sha256": "<hex>"},
    {"type": "upi",   "sha256": "<hex>"},
    {"type": "host",  "sha256": "<hex>"}
  ],
  "signature": "<base64 Ed25519 over canonical JSON of all fields except 'signature'>"
}
```
- `phone`: last 10 digits. `upi`: lowercase handle. `host`: lowercase hostname without `www.`.
- Canonical JSON = `json.dumps(obj, sort_keys=True, separators=(",", ":"))` (UTF-8).
- Clients reject packs with invalid signatures or `version` ≤ installed version.
- QR transport: split into numbered chunks; each chunk < 2 KB.
