# Architecture

```
INPUT ──► OFFLINE ASR ──► NORMALISE ──► VERDICT ENGINE ──► RISK LEVEL ──► ACT
voice     whisper.cpp     lang-ID       L1 lookup           RED            voice alert
SMS       or Vosk         numbers       L2 intent AI        AMBER          one-tap 1930
link      (hi/ta/te)      UPI IDs       L3 heuristics       GREEN          Family Guardian
                          URLs
```

## Components
| Layer | Tech | Notes |
|---|---|---|
| App | Kotlin, Jetpack, Android 7+ | APK < 60 MB, lazy model loading |
| ASR | whisper.cpp (tiny, int8) / Vosk small | swappable behind `SpeechEngine` interface |
| L1 | SQLite + SQLCipher, Bloom filter | hashed (SHA-256) numbers, UPI IDs, hostnames |
| L2 | TensorFlow Lite text classifier (< 5 MB) | scam types: lottery, kyc, digital_arrest, refund, loan, otp |
| L3 | Regex + Aho-Corasick | sender mismatch, look-alike domains, urgency, OTP asks |
| Voice out | pre-recorded clips + offline TTS | hi / ta / te |
| Sync | Ed25519-signed delta packs | Wi-Fi / Bluetooth / QR / auto when online |
| Cloud (optional) | FastAPI + PostgreSQL | report triage and pack signing only |

## Verdict combination
```
if L1 hit:                      RED
else score = max(L2, L3) + 0.3 * min(L2, L3)   (capped at 1.0)
     score >= 0.75 → RED ; score >= 0.35 → AMBER ; else GREEN
```
GREEN means *no known threat*; the spoken message always reminds: "never share OTP or PIN".
Thresholds are tunable and must be validated on field data.

## Intent-over-transcript
ASR output is noisy for dialects. L2 therefore uses bag-of-intent signals (multilingual keyword
stems → later a small TFLite classifier) instead of requiring exact phrases. A "did you mean…?" voice
confirmation is used when confidence is low.

## Threat packs
See [threat-pack-format.md](threat-pack-format.md). Packs are KB-sized, versioned, and verified with an
embedded Ed25519 public key before import. The app shows "last updated" and falls back to L2/L3 when stale.

## Failure modes
| Risk | Mitigation |
|---|---|
| ASR error | intent not exact words, keyword fallback, voice confirm |
| Stale threat list | signed delta packs via Mesh, "last updated" notice |
| False alarm / miss | 3 levels, AMBER defaults to "verify", never "100% safe" |
| SMS permission policy | share-to-app / paste check; background scan only in partner builds |
