"""L2: scam-script intent scoring.

Reference baseline: multilingual keyword/stem signals. The Android app replaces this with a
< 5 MB TFLite classifier trained on the scam-script corpus; this module is the benchmark & fallback.
Intent-over-transcript: we need a few signals, not an exact sentence.
"""

SIGNALS = {
    "lottery": [
        ("lottery", .5), ("lucky draw", .5), ("jackpot", .5), ("prize", .3), ("winner", .3), ("won ", .2),
        ("processing fee", .3), ("claim", .2),
        ("लॉटरी", .5), ("इनाम", .3), ("जीती", .3),
        ("லாட்டரி", .5), ("பரிசு", .3), ("வென்ற", .3),
        ("లాటరీ", .5), ("బహుమతి", .3), ("గెలుచుకున్న", .3),
    ],
    "kyc": [
        ("kyc", .5), ("account will be blocked", .3), ("account blocked", .3), ("account suspended", .3),
        ("update pan", .4), ("aadhaar update", .4), ("verify your account", .3),
        ("केवाईसी", .5), ("खाता बंद", .3),
        ("கேஒய்சி", .5), ("கணக்கு முடக்க", .3),
        ("కేవైసీ", .5), ("ఖాతా బ్లాక్", .3),
    ],
    "digital_arrest": [
        ("digital arrest", .6), ("arrest warrant", .5), ("cbi", .4), ("narcotics", .4), ("customs", .2),
        ("money laundering", .4), ("do not tell anyone", .4), ("don't tell anyone", .4), ("video call", .15),
        ("parcel", .2),
        ("डिजिटल अरेस्ट", .6), ("सीबीआई", .4), ("वारंट", .3), ("गिरफ्तार", .3), ("किसी को मत बता", .4),
        ("டிஜிட்டல் அரெஸ்ட்", .6), ("சிபிஐ", .4), ("வாரண்ட்", .3), ("யாரிடமும் சொல்ல", .4),
        ("డిజిటల్ అరెస్ట్", .6), ("సీబీఐ", .4), ("వారెంట్", .3), ("ఎవరికీ చెప్ప", .4),
    ],
    "refund": [
        ("refund", .4), ("cashback", .3), ("wrong transfer", .3), ("wrongly transferred", .3),
        ("electricity bill", .2), ("disconnect", .2), ("install this app", .4), ("anydesk", .5), ("teamviewer", .5),
    ],
    "loan": [
        ("instant loan", .5), ("pre-approved loan", .5), ("loan approved", .4), ("processing fee", .3),
        ("no documents", .3),
    ],
    "otp": [
        ("cvv", .4), ("share otp", .5), ("send otp", .5), ("otp batao", .5), ("card number", .3),
        ("ओटीपी बताइए", .5), ("ஓடிபி சொல்ல", .5), ("ఓటీపీ చెప్ప", .5),
    ],
}


def score(text: str):
    """Return (best_type, score 0..1, matched_terms)."""
    t = text.lower()
    best, best_s, best_hits = None, 0.0, []
    for kind, sigs in SIGNALS.items():
        s, hits = 0.0, []
        for term, w in sigs:
            if term in t:
                s += w
                hits.append(term)
        if s > best_s:
            best, best_s, best_hits = kind, s, hits
    return best, min(1.0, best_s), best_hits
