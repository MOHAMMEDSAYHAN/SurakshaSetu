"""L3: SMS / link heuristics."""
import re

LEGIT_DOMAINS = (
    "sbi.co.in", "onlinesbi.sbi", "hdfcbank.com", "icicibank.com", "axisbank.com",
    "paytm.com", "phonepe.com", "npci.org.in", "incometax.gov.in", "uidai.gov.in", "cybercrime.gov.in",
)
BRAND_WORDS = ("sbi", "hdfc", "icici", "axis", "paytm", "phonepe", "npci", "incometax", "uidai", "aadhaar", "kyc")
RISKY_TLDS = (".xyz", ".top", ".click", ".link", ".online", ".site", ".live", ".cc")
SHORTENERS = ("bit.ly", "tinyurl.com", "cutt.ly", "t.co", "rb.gy", "is.gd", "goo.gl", "shorturl.at")
URGENCY = ("immediately", "urgent", "today", "within 24 hours", "last chance", "expire", "right now",
           "तुरंत", "अभी", "உடனே", "இன்றே", "వెంటనే", "ఇప్పుడే")
OTP_ASK = re.compile(r"(?<!not )(?<!never )(?<!n't )\b(share|send|tell|give|read out)\b.{0,25}\b(otp|pin|cvv|password)\b", re.I)


def _is_legit(host: str) -> bool:
    return any(host == d or host.endswith("." + d) for d in LEGIT_DOMAINS)


def score(text: str, hosts: list):
    s, reasons = 0.0, []
    t = text.lower()
    for h in hosts:
        if _is_legit(h):
            continue
        if any(b in h for b in BRAND_WORDS):
            s += .6
            reasons.append(f"look-alike link ({h})")
        if h in SHORTENERS:
            s += .3
            reasons.append("shortened link hides the real site")
        if h.endswith(RISKY_TLDS):
            s += .2
            reasons.append("link uses a risky domain ending")
    if any(u in t for u in URGENCY):
        s += .15
        reasons.append("pressure to act quickly")
    if OTP_ASK.search(text):
        s += .5
        reasons.append("asks you to share OTP/PIN")
    return min(1.0, s), reasons
