import csv
from .bloom import BloomFilter
from .normalise import sha, norm_phone, norm_upi, norm_host


class KnownThreats:
    """L1: hashed lookup of numbers, UPI IDs and hostnames."""

    def __init__(self):
        self.bloom = BloomFilter()
        self.exact = set()

    def _add(self, kind: str, digest: str):
        key = f"{kind}:{digest}"
        self.exact.add(key)
        self.bloom.add(key)

    def add_plain(self, kind: str, value: str):
        n = {"phone": norm_phone, "upi": norm_upi, "host": norm_host}[kind](value)
        if n:
            self._add(kind, sha(n))

    def add_hash(self, kind: str, digest: str):
        self._add(kind, digest)

    def load_csv(self, path: str):
        with open(path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                self.add_plain(row["type"], row["value"])
        return self

    def load_entries(self, entries):
        for e in entries:
            self.add_hash(e["type"], e["sha256"])
        return self

    def hit(self, kind: str, normalised: str) -> bool:
        key = f"{kind}:{sha(normalised)}"
        return key in self.bloom and key in self.exact

    def check(self, found: dict) -> list:
        reasons = []
        for p in found["phones"]:
            if self.hit("phone", p):
                reasons.append("number is in known-scam list")
        for u in found["upis"]:
            if self.hit("upi", u):
                reasons.append("UPI ID is in known-scam list")
        for h in found["hosts"]:
            if self.hit("host", h):
                reasons.append("link is in known-scam list")
        return reasons
