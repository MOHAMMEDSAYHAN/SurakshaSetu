import hashlib
import re

PHONE_RE = re.compile(r"(?<!\d)(?:\+?91[\s-]?)?([6-9](?:[\s-]?\d){9})(?!\d)")
UPI_RE = re.compile(r"\b[\w.\-]{2,}@[a-zA-Z]{2,}\b")
URL_RE = re.compile(
    r"(?i)\b(?:https?://)?(?:[a-z0-9-]+\.)+(?:com|in|co|net|org|xyz|top|click|link|info|online|site|live|cc|me|ly|gl|sbi)\b(?:/\S*)?"
)


def sha(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def norm_phone(s: str):
    d = re.sub(r"\D", "", s)
    return d[-10:] if len(d) >= 10 else None


def norm_upi(s: str) -> str:
    return s.strip().lower()


def norm_host(s: str) -> str:
    s = re.sub(r"(?i)^https?://", "", s.strip())
    host = s.split("/")[0].split(":")[0].lower()
    return host[4:] if host.startswith("www.") else host


def extract(text: str) -> dict:
    upis = [norm_upi(m.group(0)) for m in UPI_RE.finditer(text)]
    no_upi = UPI_RE.sub(" ", text)
    phones = []
    for m in PHONE_RE.finditer(no_upi):
        p = norm_phone(m.group(1))
        if p:
            phones.append(p)
    hosts = [norm_host(m.group(0)) for m in URL_RE.finditer(no_upi)]
    return {"phones": phones, "upis": upis, "hosts": hosts}
