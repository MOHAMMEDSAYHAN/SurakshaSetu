from .verdict import Risk, Verdict
from .normalise import extract
from .l1_lookup import KnownThreats
from . import l2_intent, l3_heuristics

RED_AT = 0.75
AMBER_AT = 0.35


class VerdictEngine:
    """3-layer offline Verdict Engine: L1 known threats -> L2 intent -> L3 heuristics."""

    def __init__(self, threats: KnownThreats | None = None):
        self.threats = threats or KnownThreats()

    def check(self, text: str) -> Verdict:
        found = extract(text)
        l1 = self.threats.check(found)
        scam_type, l2, l2_terms = l2_intent.score(text)
        l3, l3_reasons = l3_heuristics.score(text, found["hosts"])
        scores = {"L1": 1.0 if l1 else 0.0, "L2": l2, "L3": l3}

        reasons = list(l1)
        if l2 >= 0.3 and scam_type:
            reasons.append(f"sounds like a {scam_type.replace('_', ' ')} scam")
        reasons += l3_reasons

        if l1:
            return Verdict(Risk.RED, scam_type, reasons, scores)

        combined = min(1.0, max(l2, l3) + 0.3 * min(l2, l3))
        scores["combined"] = combined
        if combined >= RED_AT:
            risk = Risk.RED
        elif combined >= AMBER_AT:
            risk = Risk.AMBER
        else:
            risk = Risk.GREEN
        return Verdict(risk, scam_type if risk != Risk.GREEN else None, reasons, scores)
