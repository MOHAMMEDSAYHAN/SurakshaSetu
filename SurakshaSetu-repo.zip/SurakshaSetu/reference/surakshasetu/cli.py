import sys
from .engine import VerdictEngine
from .l1_lookup import KnownThreats


def main():
    text = " ".join(sys.argv[1:]) or sys.stdin.read()
    engine = VerdictEngine(KnownThreats().load_csv("data/sample/known_threats.csv"))
    print(engine.check(text))


if __name__ == "__main__":
    main()
