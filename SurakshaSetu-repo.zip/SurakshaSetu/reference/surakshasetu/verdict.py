from dataclasses import dataclass, field
from enum import IntEnum
from typing import Optional


class Risk(IntEnum):
    GREEN = 0   # no known threat (NOT "safe")
    AMBER = 1   # verify before acting
    RED = 2     # stop


@dataclass
class Verdict:
    risk: Risk
    scam_type: Optional[str] = None
    reasons: list = field(default_factory=list)
    scores: dict = field(default_factory=dict)

    def __str__(self) -> str:
        t = f" ({self.scam_type})" if self.scam_type else ""
        return f"{self.risk.name}{t}: " + "; ".join(self.reasons or ["no known threat"])
