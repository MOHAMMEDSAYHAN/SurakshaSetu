import hashlib


class BloomFilter:
    """Tiny Bloom filter for instant 'definitely not in list' answers."""

    def __init__(self, size_bits: int = 1 << 16, hashes: int = 4):
        self.size = size_bits
        self.k = hashes
        self.bits = bytearray(size_bits // 8 + 1)

    def _idx(self, item: str):
        h = hashlib.sha256(item.encode()).digest()
        for i in range(self.k):
            yield int.from_bytes(h[i * 4:(i + 1) * 4], "big") % self.size

    def add(self, item: str) -> None:
        for i in self._idx(item):
            self.bits[i // 8] |= 1 << (i % 8)

    def __contains__(self, item: str) -> bool:
        return all(self.bits[i // 8] & (1 << (i % 8)) for i in self._idx(item))
