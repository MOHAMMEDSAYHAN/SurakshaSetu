---
name: New scam script / false positive
about: Help us improve detection (use synthetic or anonymised text only)
---
**Language:** Hindi / Tamil / Telugu / English
**Type:** lottery / KYC / digital arrest / refund / loan / OTP / other
**Text (anonymised — remove names, numbers, UPI IDs):**

**Expected verdict:** RED / AMBER / GREEN
