#!/usr/bin/env python3
"""Build / sign / verify SurakshaSetu threat packs (Ed25519)."""
import argparse, base64, csv, json, os, sys, datetime
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "reference"))
from surakshasetu.normalise import sha, norm_phone, norm_upi, norm_host  # noqa: E402

NORM = {"phone": norm_phone, "upi": norm_upi, "host": norm_host}


def canonical(pack: dict) -> bytes:
    body = {k: v for k, v in pack.items() if k != "signature"}
    return json.dumps(body, sort_keys=True, separators=(",", ":")).encode("utf-8")


def keygen(out):
    os.makedirs(out, exist_ok=True)
    k = Ed25519PrivateKey.generate()
    with open(os.path.join(out, "private.pem"), "wb") as f:
        f.write(k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    with open(os.path.join(out, "public.pem"), "wb") as f:
        f.write(k.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))


def build(csv_path, version=1):
    entries = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            n = NORM[r["type"]](r["value"])
            if n:
                entries.append({"type": r["type"], "sha256": sha(n)})
    return {"format": 1, "version": version,
            "created": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "entries": entries}


def sign(pack, private_pem: bytes):
    key = serialization.load_pem_private_key(private_pem, password=None)
    pack = dict(pack)
    pack["signature"] = base64.b64encode(key.sign(canonical(pack))).decode()
    return pack


def verify(pack, public_pem: bytes) -> bool:
    pub = serialization.load_pem_public_key(public_pem)
    try:
        pub.verify(base64.b64decode(pack.get("signature", "")), canonical(pack))
        return True
    except (InvalidSignature, ValueError):
        return False


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    a = sp.add_parser("keygen"); a.add_argument("--out", required=True)
    b = sp.add_parser("build"); b.add_argument("--csv", required=True); b.add_argument("--out", required=True); b.add_argument("--version", type=int, default=1)
    c = sp.add_parser("sign"); c.add_argument("--pack", required=True); c.add_argument("--key", required=True); c.add_argument("--out", required=True)
    d = sp.add_parser("verify"); d.add_argument("--pack", required=True); d.add_argument("--pub", required=True)
    x = ap.parse_args()
    if x.cmd == "keygen":
        keygen(x.out)
    elif x.cmd == "build":
        json.dump(build(x.csv, x.version), open(x.out, "w"), indent=2)
    elif x.cmd == "sign":
        json.dump(sign(json.load(open(x.pack)), open(x.key, "rb").read()), open(x.out, "w"), indent=2)
    elif x.cmd == "verify":
        ok = verify(json.load(open(x.pack)), open(x.pub, "rb").read())
        print("VALID" if ok else "INVALID"); sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
